package com.example.rest;

import java.util.HashMap;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import controller.tda.graph.Graph;
import controller.tda.graph.GraphDirect;
import controller.tda.graph.GraphNoDirect;
import controller.tda.graph.GraphLabelDirect;
import controller.tda.graph.GraphLabelNoDirect;
import controller.Dao.servicies.FamiliaServicies;
import models.Familia;
import controller.tda.list.LinkedList;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getIt() {
        HashMap mapa = new HashMap<>();
        GraphLabelNoDirect graph = null;

        try {
            FamiliaServicies ps = new FamiliaServicies();
            LinkedList<Familia> lp = ps.listAll();
            if (!lp.isEmpty()) {
                graph = new GraphLabelNoDirect<>(lp.getSize(), Familia.class);
                Familia[] m = lp.toArray();
                for (int i = 0; i < lp.getSize(); i++) {
                    graph.labelsVertices((i + 1), m[i]);
                }

            }
            // graph.labelsVertices(1, "Maria");
            // graph.labelsVertices(2, "Jara");
            // graph.labelsVertices(3, "Yosibel");
            // graph.labelsVertices(4, "Eberson");
            // graph.labelsVertices(5, "Paez");

            // graph.insertEdgeL("Maria", "Jara", 8.0f);

            graph.drawGraph();

            // graph.add_edge(1, 10, 19.0f);
        } catch (Exception e) {
            System.out.println("Error MyResource " + e);
            mapa.put("msg", "Ok");
            mapa.put("data", e.toString());
            return Response.status(Status.BAD_REQUEST).entity(mapa).build();
        }
        System.out.println(graph.toString());
        mapa.put("msg", "OK");
        mapa.put("data", graph.toString());
        System.out.println(graph.toString());
        return Response.ok(mapa).build();

    }

}
