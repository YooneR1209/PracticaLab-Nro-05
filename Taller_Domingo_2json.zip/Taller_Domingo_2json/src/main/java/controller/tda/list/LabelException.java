package controller.tda.list;

public class LabelException extends Exception {
    public LabelException() {

    }

    public LabelException(String msg) {
        super(msg);
    }
}
