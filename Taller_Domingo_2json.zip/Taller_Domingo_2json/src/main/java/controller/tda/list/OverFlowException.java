package controller.tda.list;

public class OverFlowException extends Exception {
    public OverFlowException() {

    }

    public OverFlowException(String msg) {
        super(msg);
    }
    
}
